<?php
namespace FSS\Includes;

if ( ! defined( 'ABSPATH' ) ) exit;

class Core {

    public function __construct() {
        $this->load_dependencies();
        $this->init_modules();
    }

    private function load_dependencies() {
        require_once FSS_PLUGIN_DIR . 'includes/Helpers.php';
        require_once FSS_PLUGIN_DIR . 'includes/Logger.php';
        require_once FSS_PLUGIN_DIR . 'includes/Purger.php';
        require_once FSS_PLUGIN_DIR . 'includes/Preloader.php';
        require_once FSS_PLUGIN_DIR . 'includes/Excluder.php';
        require_once FSS_PLUGIN_DIR . 'includes/Headers.php';
        require_once FSS_PLUGIN_DIR . 'includes/Updater.php';
    }

    private function init_modules() {
        $this->maybe_migrate();

        new Purger();
        new Excluder();
        new Headers();

        $preloader = new Preloader();
        $updater   = new Updater();

        require_once FSS_PLUGIN_DIR . 'includes/Admin/AdminBar.php';
        new Admin\AdminBar( $updater );

        if ( is_admin() ) {
            require_once FSS_PLUGIN_DIR . 'includes/Admin/DashboardStats.php';
            require_once FSS_PLUGIN_DIR . 'includes/Admin/Settings.php';

            new Admin\DashboardStats();
            new Admin\Settings();
        }

        register_activation_hook( FSS_PLUGIN_FILE, [ $preloader, 'schedule_event' ] );
        register_deactivation_hook( FSS_PLUGIN_FILE, [ $preloader, 'clear_schedule' ] );

        register_activation_hook( FSS_PLUGIN_FILE, [ $updater, 'schedule_event' ] );
        register_deactivation_hook( FSS_PLUGIN_FILE, [ $updater, 'clear_schedule' ] );

        register_activation_hook( FSS_PLUGIN_FILE, [ $this, 'set_default_options' ] );
    }

    public function set_default_options() {
        $defaults = [
            'fss_exclude_urls'         => implode( "\n", [
                '/wp-admin/',
                '/wp-login.php',
                '/wp-cron.php',
                '/xmlrpc.php',
                '/wp-json/',
                '/sitemap.xml',
                '/cart/',
                '/checkout/',
                '/my-account/',
            ] ),
            'fss_always_purge_urls'    => '',
            'fss_preload_enabled'      => 1,
            'fss_preload_batch_size'   => 100,
            'fss_preload_concurrency'  => 1,
            'fss_preload_batch_delay'  => 10,
            'fss_preload_schedule'     => 'daily',
            'fss_preload_date_range'   => 60,
            'fss_preload_max_posts'    => 0,
            'fss_cache_max_age'        => 43200,
            'fss_cache_s_maxage'       => 86400,
        ];

        foreach ( $defaults as $key => $value ) {
            if ( false === get_option( $key ) ) {
                update_option( $key, $value );
            }
        }
    }

    private function maybe_migrate() {
        $db_version = get_option( 'fss_cache_version', '' );

        if ( $db_version !== FSS_VERSION ) {
            update_option( 'fss_cache_version', FSS_VERSION );
            delete_transient( 'fss_update_manifest' );
        }

        if ( get_option( 'fss_migrated_1103', false ) === false ) {
            update_option( 'fss_preload_schedule', 'lifetime' );
            wp_clear_scheduled_hook( Preloader::CRON_HOOK );
            update_option( 'fss_migrated_1103', true );
        }
    }
}
