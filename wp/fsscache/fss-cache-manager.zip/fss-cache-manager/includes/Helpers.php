<?php
namespace FSS\Includes;

if ( ! defined( 'ABSPATH' ) ) exit;

class Helpers {

    const CACHE_PATH = '/var/cache/nginx/cache';

    public static function get_cache_path() {
        return defined( 'FSS_CACHE_PATH' ) ? FSS_CACHE_PATH : self::CACHE_PATH;
    }

    public static function purge_url( $url ) {
        $parsed = parse_url( $url );
        if ( ! $parsed || ! isset( $parsed['host'] ) ) return false;

        $host = $parsed['host'];
        $uri  = isset( $parsed['path'] ) ? $parsed['path'] : '/';
        if ( isset( $parsed['query'] ) ) {
            $uri .= '?' . $parsed['query'];
        }

        // Coba kedua scheme (http & https) karena Nginx $scheme
        // bergantung pada koneksi aktual, bukan apa yang WordPress tahu.
        $schemes = [ 'https', 'http' ];

        $deleted = 0;
        $variants = [ '0', '1' ]; // mobile variants

        foreach ( $schemes as $scheme ) {
            foreach ( $variants as $is_mobile ) {
                $key  = $scheme . 'GET' . $host . $uri . $is_mobile;
                $hash = md5( $key );

                $level1 = substr( $hash, -1 );
                $level2 = substr( $hash, -3, 2 );
                $path   = self::get_cache_path() . '/' . $level1 . '/' . $level2 . '/' . $hash;

                if ( file_exists( $path ) ) {
                    if ( @unlink( $path ) ) {
                        $deleted++;
                    } else {
                        Logger::log( "Purge failed (unlink error): $path | key: $key" );
                    }
                }
            }
        }

        if ( $deleted === 0 ) {
            // Log hanya jika ada masalah (file tidak ditemukan)
            $sample_key = $schemes[0] . 'GET' . $host . $uri . '0';
            $sample_hash = md5( $sample_key );
            $level1 = substr( $sample_hash, -1 );
            $level2 = substr( $sample_hash, -3, 2 );
            $expected_path = self::get_cache_path() . '/' . $level1 . '/' . $level2 . '/' . $sample_hash;
            Logger::log( "Purge miss: $url | key: $sample_key | path: $expected_path" );
        }

        return $deleted > 0;
    }

    public static function purge_all() {
        $path = self::get_cache_path();
        if ( ! is_dir( $path ) || ! is_readable( $path ) ) return 0;

        $count = 0;

        try {
            $iter = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $path, \FilesystemIterator::SKIP_DOTS ),
                \RecursiveIteratorIterator::CHILD_FIRST
            );
            $iter->setMaxDepth( 3 );

            foreach ( $iter as $item ) {
                if ( $item->isFile() && $item->isWritable() ) {
                    @unlink( $item->getPathname() );
                    $count++;
                }
            }
        } catch ( \Exception $e ) {
            Logger::error( 'Purge all failed: ' . $e->getMessage() );
        }

        return $count;
    }

    public static function purge_urls( array $urls ) {
        $deleted = 0;
        foreach ( $urls as $url ) {
            if ( self::purge_url( $url ) ) $deleted++;
        }
        return $deleted;
    }
}
