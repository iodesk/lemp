<?php
namespace FSS\Includes;

if ( ! defined( 'ABSPATH' ) ) exit;

class Headers {

    private static $paths = null;

    public function __construct() {
        add_action( 'template_redirect', [ $this, 'send_cache_headers' ], 1 );
    }

    public function send_cache_headers() {
        if ( headers_sent() ) return;
        if ( is_admin() ) return;
        if ( is_user_logged_in() ) return;

        if ( $this->is_excluded() ) {
            header( 'Cache-Control: private, no-store, no-cache, must-revalidate' );
            header( 'X-Cache-Disabled: true' );
            return;
        }

        $max_age   = $this->get_max_age();
        $s_maxage  = $this->get_s_maxage();
        $post_id   = $this->get_current_post_id();

        header( "Cache-Control: public, max-age={$max_age}, s-maxage={$s_maxage}" );
        header( 'X-Cache-Enabled: true' );
        header( 'Vary: Accept-Encoding' );

        $post_id  = $this->get_current_post_id();
        $modified = 0;

        if ( $post_id ) {
            $modified = intval( get_post_modified_time( 'U', true, $post_id ) );
        }

        if ( ! $modified ) {
            $modified = intval( get_lastpostmodified( 'GMT' ) ? strtotime( get_lastpostmodified( 'GMT' ) ) : time() );
        }

        $etag_seed = $_SERVER['REQUEST_URI'] . $modified . $max_age;
        header( 'ETag: "' . md5( $etag_seed ) . '"' );
        header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', $modified ) . ' GMT' );
    }

    private function get_max_age() {
        return max( 0, intval( get_option( 'fss_cache_max_age', 43200 ) ) );
    }

    private function get_s_maxage() {
        return max( 0, intval( get_option( 'fss_cache_s_maxage', 86400 ) ) );
    }

    private function get_current_post_id() {
        return is_singular() ? get_queried_object_id() : 0;
    }

    private function is_excluded() {
        if ( self::$paths === null ) {
            $excludes = get_option( 'fss_exclude_urls', '' );
            if ( empty( $excludes ) ) {
                self::$paths = [];
            } else {
                $raw = explode( "\n", str_replace( "\r", '', $excludes ) );
                self::$paths = array_values( array_filter( array_map( 'trim', $raw ) ) );
            }
        }

        if ( empty( self::$paths ) ) return false;

        $request_uri = parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );

        foreach ( self::$paths as $path ) {
            if ( strpos( $request_uri, $path ) !== false ) {
                return true;
            }
        }

        return false;
    }
}
