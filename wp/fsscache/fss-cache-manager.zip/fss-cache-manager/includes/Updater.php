<?php
namespace FSS\Includes;

use FSS\Includes\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class Updater {

    const MANIFEST_URL = 'https://vps.fio.link/wp/fsscache/fss-cache-manager-manifest.json';
    const CRON_HOOK = 'fss_check_update_event';

    public function __construct() {
        add_action( self::CRON_HOOK, [ $this, 'check_for_updates' ] );
        
        // WordPress Plugin Update API Integration
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_for_plugin_update' ] );
        add_filter( 'plugins_api', [ $this, 'plugin_info' ], 10, 3 );
    }

    public function schedule_event() {
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            // Schedule daily at midnight (00:00)
            $midnight = strtotime( 'tomorrow midnight' );
            wp_schedule_event( $midnight, 'daily', self::CRON_HOOK );
        }
    }

    public function clear_schedule() {
        wp_clear_scheduled_hook( self::CRON_HOOK );
    }

    public function check_for_updates() {
        Logger::log( 'OTA: Checking for updates...' );

        $response = wp_remote_get( self::MANIFEST_URL, [
            'timeout' => 10,
            'sslverify' => false
        ] );

        if ( is_wp_error( $response ) ) {
            Logger::log( 'OTA: Failed to fetch manifest - ' . $response->get_error_message() );
            return;
        }

        $body = wp_remote_retrieve_body( $response );
        $manifest = json_decode( $body, true );

        if ( ! $manifest || ! isset( $manifest['version'] ) ) {
            Logger::log( 'OTA: Invalid manifest format' );
            return;
        }

        $remote_version = $manifest['version'];
        $current_version = FSS_VERSION;

        // Compare versions
        if ( version_compare( $remote_version, $current_version, '>' ) ) {
            Logger::log( "OTA: New version available: $remote_version (current: $current_version)" );
            $this->perform_update( $manifest );
        } else {
            Logger::log( "OTA: Already up-to-date (v$current_version)" );
        }
    }

    /**
     * Manual update check (called from Admin UI)
     * Returns result for immediate feedback
     */
    public function check_for_updates_manual() {
        $response = wp_remote_get( self::MANIFEST_URL, [
            'timeout' => 10,
            'sslverify' => false
        ] );

        if ( is_wp_error( $response ) ) {
            return [
                'updated' => false,
                'message' => 'Failed to check for updates: ' . $response->get_error_message()
            ];
        }

        $body = wp_remote_retrieve_body( $response );
        $manifest = json_decode( $body, true );

        if ( ! $manifest || ! isset( $manifest['version'] ) ) {
            return [
                'updated' => false,
                'message' => 'Invalid update manifest'
            ];
        }

        $remote_version = $manifest['version'];
        $current_version = FSS_VERSION;

        if ( version_compare( $remote_version, $current_version, '>' ) ) {
            $success = $this->perform_update( $manifest );
            if ( $success ) {
                return [
                    'updated' => true,
                    'message' => "Updated to v$remote_version. Please refresh the page."
                ];
            } else {
                return [
                    'updated' => false,
                    'message' => "Update to v$remote_version failed. Check logs."
                ];
            }
        } else {
            return [
                'updated' => false,
                'message' => "Already up-to-date (v$current_version)"
            ];
        }
    }

    private function perform_update( $manifest ) {
        $download_url = $manifest['download_url'];

        Logger::log( "OTA: Downloading update from $download_url" );

        if ( ! function_exists( 'download_url' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if ( ! function_exists( 'unzip_file' ) ) {
            WP_Filesystem();
        }

        $temp_file = download_url( $download_url );

        if ( is_wp_error( $temp_file ) ) {
            Logger::log( 'OTA: Download failed - ' . $temp_file->get_error_message() );
            return false;
        }

        $temp_dir = WP_CONTENT_DIR . '/upgrade/fss-cache-manager-temp';

        if ( file_exists( $temp_dir ) ) {
            $this->delete_directory( $temp_dir );
        }

        $unzip_result = unzip_file( $temp_file, $temp_dir );

        if ( is_wp_error( $unzip_result ) ) {
            Logger::log( 'OTA: Extraction failed - ' . $unzip_result->get_error_message() );
            @unlink( $temp_file );
            return false;
        }

        $plugin_dir = FSS_PLUGIN_DIR;

        $backup_dir = WP_CONTENT_DIR . '/upgrade/fss-cache-manager-backup';
        if ( file_exists( $backup_dir ) ) {
            $this->delete_directory( $backup_dir );
        }

        if ( ! @rename( $plugin_dir, $backup_dir ) ) {
            Logger::log( 'OTA: Failed to backup current plugin.' );
            @unlink( $temp_file );
            $this->delete_directory( $temp_dir );
            return false;
        }

        $extracted_plugin = $temp_dir . '/fss-cache-manager';
        if ( ! file_exists( $extracted_plugin ) ) {
            $extracted_plugin = $temp_dir;
        }

        if ( ! @rename( $extracted_plugin, $plugin_dir ) ) {
            Logger::log( 'OTA: Failed to replace plugin files. Rolling back...' );
            @rename( $backup_dir, $plugin_dir );
            @unlink( $temp_file );
            return false;
        }

        @unlink( $temp_file );
        $this->delete_directory( $temp_dir );
        $this->delete_directory( $backup_dir );

        Logger::log( "OTA: Successfully updated to v{$manifest['version']}" );
        update_option( 'fss_cache_version', $manifest['version'] );
        return true;
    }

    /**
     * Hook into WordPress Plugin Update Check
     * Injects our update info into the transient
     */
    public function check_for_plugin_update( $transient ) {
        if ( empty( $transient->checked ) ) {
            return $transient;
        }

        $manifest = $this->get_manifest();
        
        if ( ! $manifest ) {
            return $transient;
        }

        $plugin_slug = plugin_basename( FSS_PLUGIN_FILE );
        $remote_version = $manifest['version'];
        $current_version = FSS_VERSION;

        if ( version_compare( $remote_version, $current_version, '>' ) ) {
            $transient->response[ $plugin_slug ] = (object) [
                'slug'        => 'fss-cache-manager',
                'plugin'      => $plugin_slug,
                'new_version' => $remote_version,
                'url'         => 'https://vps.fio.link',
                'package'     => $manifest['download_url'],
                'tested'      => $manifest['tested_up_to'] ?? '6.7',
            ];
        }

        return $transient;
    }

    /**
     * Provide plugin information for the update details popup
     */
    public function plugin_info( $false, $action, $args ) {
        if ( $action !== 'plugin_information' ) {
            return $false;
        }

        if ( ! isset( $args->slug ) || $args->slug !== 'fss-cache-manager' ) {
            return $false;
        }

        $manifest = $this->get_manifest();
        
        if ( ! $manifest ) {
            return $false;
        }

        return (object) [
            'name'          => 'FSS Cache Manager',
            'slug'          => 'fss-cache-manager',
            'version'       => $manifest['version'],
            'author'        => '<a href="https://fio.link">FSS</a>',
            'homepage'      => 'https://vps.fio.link',
            'download_link' => $manifest['download_url'],
            'sections'      => [
                'description' => 'High-performance Nginx FastCGI Cache Manager with Smart Purge and Sitemap Preloader.',
                'changelog'   => $manifest['changelog'] ?? 'Bug fixes and improvements.',
            ],
            'tested'        => $manifest['tested_up_to'] ?? '6.7',
            'requires'      => $manifest['min_wp_version'] ?? '5.0',
        ];
    }

    /**
     * Fetch and cache manifest data
     */
    private function get_manifest() {
        $transient_key = 'fss_update_manifest';
        $cached = get_transient( $transient_key );

        if ( $cached !== false ) {
            return $cached;
        }

        $response = wp_remote_get( self::MANIFEST_URL, [
            'timeout' => 10,
            'sslverify' => false
        ] );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $body = wp_remote_retrieve_body( $response );
        $manifest = json_decode( $body, true );

        if ( ! $manifest || ! isset( $manifest['version'] ) ) {
            return false;
        }

        // Cache for 12 hours
        set_transient( $transient_key, $manifest, 12 * HOUR_IN_SECONDS );

        return $manifest;
    }

    private function delete_directory( $dir ) {
        if ( ! file_exists( $dir ) ) return;
        
        $files = array_diff( scandir( $dir ), [ '.', '..' ] );
        foreach ( $files as $file ) {
            $path = "$dir/$file";
            is_dir( $path ) ? $this->delete_directory( $path ) : unlink( $path );
        }
        rmdir( $dir );
    }
}
