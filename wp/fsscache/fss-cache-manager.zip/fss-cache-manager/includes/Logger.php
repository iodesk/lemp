<?php
namespace FSS\Includes;

if ( ! defined( 'ABSPATH' ) ) exit;

class Logger {

    const OPTION_STATS = 'fss_cache_stats';

    public static function log( $message, $is_error = false ) {
        if ( ! $is_error && ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
            return;
        }

        $log_file          = WP_CONTENT_DIR . '/fss-cache.log';
        $timestamp         = current_time( 'mysql' );
        $prefix            = $is_error ? '[ERROR]' : '[INFO]';
        $formatted_message = "[{$timestamp}] [FSS Cache] {$prefix} {$message}" . PHP_EOL;

        @error_log( $formatted_message, 3, $log_file );
    }

    public static function error( $message ) {
        self::log( $message, true );
    }

    public static function start_log( $total = 0 ) {
        $stats = self::get_stats();
        if ( ! $stats ) $stats = [];

        $stats['status']     = 'running';
        $stats['start_time'] = current_time( 'mysql' );
        $stats['total']      = intval( $total );
        $stats['progress']   = 0;

        update_option( self::OPTION_STATS, $stats );
    }

    public static function set_scheduled() {
        $stats = self::get_stats();
        if ( ! $stats ) $stats = [];

        $stats['status']     = 'scheduled';
        $stats['start_time'] = current_time( 'mysql' );
        $stats['total']      = 0;
        $stats['progress']   = 0;

        update_option( self::OPTION_STATS, $stats );
    }

    public static function update_progress( $current ) {
        $stats = self::get_stats();
        if ( ! $stats ) return;

        $stats['progress'] = intval( $current );
        update_option( self::OPTION_STATS, $stats );
    }

    public static function record_stats( $count, $duration ) {
        $stats = [
            'last_run'  => current_time( 'mysql' ),
            'processed' => intval( $count ),
            'duration'  => round( $duration, 2 ),
            'status'    => 'success',
            'progress'  => intval( $count ),
            'total'     => intval( $count ),
        ];

        update_option( self::OPTION_STATS, $stats );
    }

    public static function record_stopped( $progress, $total ) {
        $stats = self::get_stats();
        if ( ! $stats ) $stats = [];

        $stats['status']   = 'stopped';
        $stats['progress'] = intval( $progress );
        $stats['total']    = intval( $total );
        $stats['last_run'] = current_time( 'mysql' );

        update_option( self::OPTION_STATS, $stats );
    }

    public static function get_stats() {
        return get_option( self::OPTION_STATS, false );
    }
}
