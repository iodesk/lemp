<?php
namespace FSS\Includes;

use FSS\Includes\Helpers;
use FSS\Includes\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class Purger {

    public function __construct() {
        add_action( 'save_post',          [ $this, 'on_save_post' ], 10, 3 );
        add_action( 'comment_post',       [ $this, 'on_comment_post' ], 10, 2 );
        add_action( 'wp_trash_post',      [ $this, 'on_trash_post' ] );
        add_action( 'untrash_post',       [ $this, 'on_trash_post' ] );
        add_action( 'before_delete_post', [ $this, 'on_trash_post' ] );
    }

    public function on_save_post( $post_id, $post, $update ) {
        if ( wp_is_post_revision( $post_id ) || $post->post_status === 'auto-draft' ) return;
        if ( $post->post_status !== 'publish' && $post->post_status !== 'private' ) return;
        $this->purge_post_related( $post_id );
    }

    public function on_comment_post( $comment_id, $comment_approved ) {
        if ( $comment_approved === 1 || $comment_approved === '1' ) {
            $comment = get_comment( $comment_id );
            if ( $comment ) $this->purge_post_related( $comment->comment_post_ID );
        }
    }

    public function on_trash_post( $post_id ) {
        $this->purge_post_related( $post_id );
    }

    private function purge_post_related( $post_id ) {
        $urls   = [];
        $urls[] = get_permalink( $post_id );
        $urls[] = home_url( '/' );

        // Purge static front page (jika pakai "A static page" di Settings > Reading)
        $front_page_id = get_option( 'page_on_front' );
        if ( $front_page_id ) {
            $urls[] = get_permalink( $front_page_id );
        }

        // Purge blog/posts page jika berbeda dari homepage
        $blog_page_id = get_option( 'page_for_posts' );
        if ( $blog_page_id ) {
            $urls[] = get_permalink( $blog_page_id );
        }

        // Purge "Always Purge URLs" — custom pages (shortcode, page builder, etc.)
        $always_purge = get_option( 'fss_always_purge_urls', '' );
        if ( ! empty( $always_purge ) ) {
            $custom_paths = array_filter( array_map( 'trim', explode( "\n", $always_purge ) ) );
            foreach ( $custom_paths as $path ) {
                // Support both full URL and relative path
                if ( strpos( $path, 'http' ) === 0 ) {
                    $urls[] = $path;
                } else {
                    $urls[] = home_url( $path );
                }
            }
        }

        // Purge paginated homepage & blog page
        $urls = array_merge( $urls, $this->get_paginated_urls( home_url( '/' ) ) );
        if ( $blog_page_id ) {
            $urls = array_merge( $urls, $this->get_paginated_urls( get_permalink( $blog_page_id ) ) );
        }

        // Purge taxonomy archives (category, tag) + paginated
        $taxonomies = [ 'category', 'post_tag' ];
        foreach ( $taxonomies as $tax ) {
            $terms = get_the_terms( $post_id, $tax );
            if ( $terms && ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $term_link = get_term_link( $term );
                    if ( ! is_wp_error( $term_link ) ) {
                        $urls[] = $term_link;
                        $urls   = array_merge( $urls, $this->get_paginated_urls( $term_link ) );
                    }
                }
            }
        }

        // Purge author archive + paginated
        $post = get_post( $post_id );
        if ( $post ) {
            $author_url = get_author_posts_url( $post->post_author );
            $urls[]     = $author_url;
            $urls       = array_merge( $urls, $this->get_paginated_urls( $author_url ) );
        }

        // Purge date-based archives
        if ( $post ) {
            $year  = get_the_date( 'Y', $post );
            $month = get_the_date( 'm', $post );
            $day   = get_the_date( 'd', $post );

            $urls[] = get_year_link( $year );
            $urls[] = get_month_link( $year, $month );
            $urls[] = get_day_link( $year, $month, $day );
        }

        $urls = array_unique( array_filter( $urls, function( $u ) {
            return $u && ! is_wp_error( $u );
        } ) );

        $deleted = Helpers::purge_urls( $urls );
        Logger::log( "Purger: Deleted $deleted cache files for post #$post_id (" . count( $urls ) . " URLs)" );
    }

    /**
     * Generate paginated URLs for a given base URL.
     * Purges page/2 through page/N based on cached files found.
     */
    private function get_paginated_urls( $base_url, $max_pages = 10 ) {
        $urls = [];
        $base_url = trailingslashit( $base_url );

        for ( $i = 2; $i <= $max_pages; $i++ ) {
            $paged_url = $base_url . 'page/' . $i . '/';
            // Hanya tambahkan jika cache file-nya ada
            if ( $this->cache_exists_for_url( $paged_url ) ) {
                $urls[] = $paged_url;
            } else {
                break; // Stop jika page berikutnya tidak ada di cache
            }
        }

        return $urls;
    }

    /**
     * Check if a cache file exists for a given URL.
     */
    private function cache_exists_for_url( $url ) {
        $parsed = parse_url( $url );
        if ( ! $parsed || ! isset( $parsed['host'] ) ) return false;

        $host = $parsed['host'];
        $uri  = isset( $parsed['path'] ) ? $parsed['path'] : '/';

        // Cek kedua scheme karena Nginx $scheme bisa http atau https
        $schemes = [ 'https', 'http' ];

        foreach ( $schemes as $scheme ) {
            $key  = $scheme . 'GET' . $host . $uri . '0';
            $hash = md5( $key );

            $level1 = substr( $hash, -1 );
            $level2 = substr( $hash, -3, 2 );
            $path   = Helpers::get_cache_path() . '/' . $level1 . '/' . $level2 . '/' . $hash;

            if ( file_exists( $path ) ) return true;
        }

        return false;
    }
}
