<?php
namespace FSS\Includes;

if ( ! defined( 'ABSPATH' ) ) exit;

class Excluder {

    private static $paths = null;

    public function __construct() {
        add_action( 'template_redirect', [ $this, 'check_exclusion' ], 0 );
    }

    public function check_exclusion() {
        if ( self::$paths === null ) {
            $excludes = get_option( 'fss_exclude_urls', '' );
            if ( empty( $excludes ) ) {
                self::$paths = [];
                return;
            }
            $raw = explode( "\n", str_replace( "\r", '', $excludes ) );
            self::$paths = array_values( array_filter( array_map( 'trim', $raw ) ) );
        }

        if ( empty( self::$paths ) ) return;

        $request_uri = parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );

        foreach ( self::$paths as $path ) {
            if ( strpos( $request_uri, $path ) !== false ) {
                $this->disable_cache();
                return;
            }
        }
    }

    private function disable_cache() {
        if ( ! headers_sent() ) {
            nocache_headers();
            header( 'X-Accel-Expires: 0' );
        }
    }
}
