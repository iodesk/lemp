<?php
namespace FSS\Includes\Admin;

use FSS\Includes\Preloader;
use FSS\Includes\Helpers;
use FSS\Includes\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class AdminBar {

    private $updater;

    public function __construct( ?\FSS\Includes\Updater $updater = null ) {
        $this->updater = $updater ?? new \FSS\Includes\Updater();
        add_action( 'admin_bar_menu', [ $this, 'add_menu' ], 999 );
        add_action( 'init', [ $this, 'handle_actions' ] );
        add_action( 'admin_notices', [ $this, 'show_notices' ] );
        add_action( 'fss_purge_all_event', [ $this, 'do_purge_all' ] );
    }

    public function add_menu( $wp_admin_bar ) {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $stats      = Logger::get_stats();
        $is_running = $stats && isset( $stats['status'] ) && in_array( $stats['status'], [ 'running', 'scheduled' ], true );

        $wp_admin_bar->add_node( [
            'id'    => 'fss-cache',
            'title' => '<span class="ab-icon dashicons dashicons-flash"></span> FSS Cache'
                       . ( $is_running ? ' <span style="color:#ffba00;font-size:10px;">●</span>' : '' ),
            'href'  => '#',
        ] );

        if ( ! is_admin() && ! empty( $_SERVER['REQUEST_URI'] ) ) {
            $current_url = home_url( $_SERVER['REQUEST_URI'] );
            $wp_admin_bar->add_node( [
                'id'     => 'fss-purge-this',
                'parent' => 'fss-cache',
                'title'  => 'Purge This Page',
                'href'   => wp_nonce_url( add_query_arg( 'fss_action', 'purge_this' ), 'fss_action' ),
                'meta'   => [ 'title' => 'Delete cache for: ' . $current_url ],
            ] );
        }

        $wp_admin_bar->add_node( [
            'id'     => 'fss-purge-all',
            'parent' => 'fss-cache',
            'title'  => 'Purge All Cache',
            'href'   => wp_nonce_url( add_query_arg( 'fss_action', 'purge_all' ), 'fss_action' ),
        ] );

        if ( $is_running ) {
            $wp_admin_bar->add_node( [
                'id'     => 'fss-stop-preload',
                'parent' => 'fss-cache',
                'title'  => '⏹ Stop Preloader',
                'href'   => wp_nonce_url( add_query_arg( 'fss_action', 'stop_preload' ), 'fss_action' ),
                'meta'   => [ 'class' => 'fss-stop-btn' ],
            ] );
        } else {
            $wp_admin_bar->add_node( [
                'id'     => 'fss-preload-now',
                'parent' => 'fss-cache',
                'title'  => 'Run Preloader Now',
                'href'   => wp_nonce_url( add_query_arg( 'fss_action', 'preload_now' ), 'fss_action' ),
            ] );
        }

        $wp_admin_bar->add_node( [
            'id'     => 'fss-check-update',
            'parent' => 'fss-cache',
            'title'  => 'Check for Updates',
            'href'   => wp_nonce_url( add_query_arg( 'fss_action', 'check_update' ), 'fss_action' ),
        ] );
    }

    public function handle_actions() {
        if ( ! isset( $_GET['fss_action'] ) || ! isset( $_GET['_wpnonce'] ) ) return;
        if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'fss_action' ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;

        $action = sanitize_key( $_GET['fss_action'] );

        if ( $action === 'purge_this' ) {
            $uri = remove_query_arg( [ 'fss_action', '_wpnonce' ] );
            $url = home_url( $uri );
            $result = Helpers::purge_url( $url );
            Logger::log( 'AdminBar: Purge this page — ' . $url . ' — ' . ( $result ? 'deleted' : 'not found' ) );
            set_transient( 'fss_action_msg', $result ? 'purge_this' : 'purge_this_fail', 30 );
            wp_safe_redirect( $uri );
            exit;
        }

        if ( $action === 'purge_all' ) {
            wp_schedule_single_event( time(), 'fss_purge_all_event' );
            spawn_cron();

            $preloader = new Preloader();
            $preloader->prepare_new_run();
            Logger::set_scheduled();

            wp_schedule_single_event( time() + 5, Preloader::CRON_HOOK );
            spawn_cron();

            set_transient( 'fss_action_msg', 'purge_all', 30 );
            wp_safe_redirect( remove_query_arg( [ 'fss_action', '_wpnonce' ] ) );
            exit;
        }

        if ( $action === 'preload_now' ) {
            $preloader = new Preloader();
            $preloader->prepare_new_run();
            Logger::set_scheduled();

            wp_schedule_single_event( time(), Preloader::CRON_HOOK );
            spawn_cron();

            set_transient( 'fss_action_msg', 'preload_now', 30 );
            wp_safe_redirect( remove_query_arg( [ 'fss_action', '_wpnonce' ] ) );
            exit;
        }

        if ( $action === 'stop_preload' ) {
            $preloader = new Preloader();
            $preloader->request_stop();
            $preloader->stop_and_cleanup();
            set_transient( 'fss_action_msg', 'stop_preload', 30 );
            wp_safe_redirect( remove_query_arg( [ 'fss_action', '_wpnonce' ] ) );
            exit;
        }

        if ( $action === 'check_update' ) {
            $result = $this->updater->check_for_updates_manual();
            set_transient( 'fss_update_msg', $result, 30 );
            wp_safe_redirect( remove_query_arg( [ 'fss_action', '_wpnonce' ] ) );
            exit;
        }
    }

    public function show_notices() {
        if ( $result = get_transient( 'fss_update_msg' ) ) {
            delete_transient( 'fss_update_msg' );
            $type = $result['updated'] ? 'success' : 'info';
            echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>FSS Cache: ' . esc_html( $result['message'] ) . '</p></div>';
        }

        if ( $action = get_transient( 'fss_action_msg' ) ) {
            delete_transient( 'fss_action_msg' );
            $messages = [
                'purge_this'      => 'Page cache deleted from disk.',
                'purge_this_fail' => 'Cache file not found on disk. Check fss-cache.log for details.',
                'purge_all'       => 'Cache purge scheduled. Preloader will start after purge completes.',
                'preload_now'     => 'Preloader started in background.',
                'stop_preload'    => 'Preloader stop signal sent. Current batch will finish then halt.',
            ];
            if ( isset( $messages[ $action ] ) ) {
                $types = [
                    'purge_this'      => 'success',
                    'purge_this_fail' => 'error',
                    'purge_all'       => 'success',
                    'preload_now'     => 'success',
                    'stop_preload'    => 'warning',
                ];
                echo '<div class="notice notice-' . $types[ $action ] . ' is-dismissible"><p>FSS Cache: ' . esc_html( $messages[ $action ] ) . '</p></div>';
            }
        }
    }

    public function do_purge_all() {
        $count = Helpers::purge_all();
        Logger::log( "AdminBar: Purge all (background) — $count cache files deleted" );
    }
}
