<?php
namespace FSS\Includes\Admin;

use FSS\Includes\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class DashboardStats {

    public function __construct() {
        add_action( 'wp_dashboard_setup', [ $this, 'add_widget' ] );
        add_action( 'wp_ajax_fss_get_widget_status', [ $this, 'ajax_get_status' ] );
    }

    public function add_widget() {
        wp_add_dashboard_widget(
            'fss_cache_stats',
            'FSS Cache Performance',
            [ $this, 'render_widget' ]
        );
    }

    private function render_stats_html( $stats ) {
        $is_running   = isset( $stats['status'] ) && $stats['status'] === 'running';
        $is_stopped   = isset( $stats['status'] ) && $stats['status'] === 'stopped';
        $is_scheduled = isset( $stats['status'] ) && $stats['status'] === 'scheduled';
        $html = '<div class="fss-stats-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">';

        if ( $is_running ) {
            $progress = isset( $stats['progress'] ) ? intval( $stats['progress'] ) : 0;
            $total    = isset( $stats['total'] ) ? intval( $stats['total'] ) : 0;
            $percent  = $total > 0 ? round( ( $progress / $total ) * 100 ) : 0;

            $stop_url = wp_nonce_url( add_query_arg( 'fss_action', 'stop_preload', admin_url() ), 'fss_action' );

            $html .= '<div style="grid-column: 1 / -1; background:#fff8e5; padding:10px; border-left:4px solid #ffba00;">';
            $html .= '<div style="display:flex; justify-content:space-between; align-items:center;">';
            $html .= '<span><span class="dashicons dashicons-update" style="animation:spin 2s linear infinite;"></span> <strong>Cache Warmer Running...</strong></span>';
            $html .= '<a href="' . esc_url( $stop_url ) . '" style="background:#d63638;color:#fff;padding:3px 10px;border-radius:3px;text-decoration:none;font-size:12px;" onclick="return confirm(\'Stop the preloader?\')">⏹ Stop</a>';
            $html .= '</div>';
            $html .= '<div style="margin-top:5px; font-weight:bold;">Progress: ' . esc_html( $progress ) . ' / ' . esc_html( $total ) . ' (' . $percent . '%)</div>';
            $html .= '<div style="background:#ddd; height:10px; border-radius:5px; margin-top:5px; overflow:hidden;">';
            $html .= '<div style="background:#ffba00; height:100%; width:' . $percent . '%; transition: width 0.5s ease;"></div>';
            $html .= '</div>';
            $html .= '<small style="display:block; margin-top:5px;">Started: ' . esc_html( $stats['start_time'] ) . '</small>';
            $html .= '</div>';
            $html .= '<style>@keyframes spin { 100% { transform:rotate(360deg); } }</style>';
        } elseif ( $is_scheduled ) {
            $html .= '<div style="grid-column: 1 / -1; background:#f0f6fc; padding:10px; border-left:4px solid #2271b1;">';
            $html .= '<span class="dashicons dashicons-clock"></span> <strong>Preloader Scheduled</strong><br>';
            $html .= '<small>Waiting for cron to start...</small>';
            $html .= '</div>';
        } elseif ( $is_stopped ) {
            $progress = isset( $stats['progress'] ) ? intval( $stats['progress'] ) : 0;
            $total    = isset( $stats['total'] ) ? intval( $stats['total'] ) : 0;

            $html .= '<div style="grid-column: 1 / -1; background:#fef0f0; padding:10px; border-left:4px solid #d63638;">';
            $html .= '<strong>⏹ Preloader Stopped</strong><br>';
            $html .= '<small>Stopped at ' . esc_html( $progress ) . ' / ' . esc_html( $total ) . ' URLs on ' . esc_html( $stats['last_run'] ) . '</small>';
            $html .= '</div>';
        } else {
            $last_run  = isset( $stats['last_run'] ) ? esc_html( $stats['last_run'] ) : '—';
            $processed = isset( $stats['processed'] ) ? intval( $stats['processed'] ) : 0;
            $duration  = isset( $stats['duration'] ) ? esc_html( $stats['duration'] ) : '—';

            $html .= '<div><strong>Last Run:</strong><br>' . $last_run . '</div>';
            $html .= '<div><strong>Pages Cached:</strong><br>' . $processed . ' URLs</div>';
            $html .= '<div><strong>Duration:</strong><br>' . $duration . ' sec</div>';
            $html .= '<div><strong>Status:</strong><br><span style="color:green;font-weight:bold;">Active</span></div>';
        }

        $html .= '</div>';

        $html .= $this->render_config_summary();

        $html .= '<hr>';
        $html .= '<p class="description">Your content is being preloaded automatically to ensure fast loading speeds for visitors.</p>';

        return [ 'html' => $html, 'is_running' => $is_running || $is_scheduled ];
    }

    private function render_config_summary() {
        $enabled     = intval( get_option( 'fss_preload_enabled', 1 ) );
        $batch_size  = intval( get_option( 'fss_preload_batch_size', 100 ) );
        $concurrency = intval( get_option( 'fss_preload_concurrency', 1 ) );
        $delay       = intval( get_option( 'fss_preload_batch_delay', 10 ) );
        $schedule    = get_option( 'fss_preload_schedule', 'daily' );
        $date_range  = intval( get_option( 'fss_preload_date_range', 60 ) );
        $max_posts   = intval( get_option( 'fss_preload_max_posts', 0 ) );

        $schedule_labels = [
            'hourly'     => 'Every Hour',
            'twicedaily' => 'Twice Daily',
            'daily'      => 'Once Daily',
            'weekly'     => 'Once a Week',
            'lifetime'   => 'Once Only',
        ];
        $schedule_label = $schedule_labels[ $schedule ] ?? $schedule;

        $status_color = $enabled ? 'green' : '#999';
        $status_text  = $enabled ? 'Enabled' : 'Disabled';

        $date_label = $date_range > 0 ? 'Last ' . $date_range . 'd' : 'All time';
        $max_label  = $max_posts > 0 ? $max_posts . ' posts' : 'No limit';

        $html  = '<hr style="margin:10px 0;">';
        $html .= '<div style="display:grid; grid-template-columns:1fr 1fr; gap:6px; font-size:12px; color:#555;">';
        $html .= '<div><strong>Preloader:</strong> <span style="color:' . $status_color . ';">' . $status_text . '</span></div>';
        $html .= '<div><strong>Schedule:</strong> ' . esc_html( $schedule_label ) . '</div>';
        $html .= '<div><strong>Batch Size:</strong> ' . $batch_size . ' URLs</div>';
        $html .= '<div><strong>Concurrency:</strong> ' . $concurrency . ' req</div>';
        $html .= '<div><strong>Date Range:</strong> ' . esc_html( $date_label ) . '</div>';
        $html .= '<div><strong>Max Posts:</strong> ' . esc_html( $max_label ) . '</div>';
        $html .= '<div><strong>Batch Delay:</strong> ' . $delay . 's</div>';
        $html .= '<div><a href="' . esc_url( admin_url( 'options-general.php?page=fss-cache-settings' ) ) . '">⚙ Settings</a></div>';
        $html .= '</div>';

        return $html;
    }

    public function render_widget() {
        $stats = Logger::get_stats();

        echo '<div id="fss-cache-widget-content">';

        if ( ! $stats ) {
            echo '<p><em>No cache data yet. Preloader will run soon.</em></p>';
            echo $this->render_config_summary();
            echo '</div>';
            return;
        }

        $result = $this->render_stats_html( $stats );
        echo $result['html'];
        echo '</div>';

        if ( $result['is_running'] ) {
            ?>
            <script>
            (function() {
                var pollInterval = setInterval(function() {
                    jQuery.post(ajaxurl, {action: 'fss_get_widget_status'}, function(response) {
                        if (response.success) {
                            jQuery('#fss-cache-widget-content').html(response.data.html);
                            if (response.data.status !== 'running') {
                                clearInterval(pollInterval);
                            }
                        }
                    });
                }, 10000);
            })();
            </script>
            <?php
        }
    }

    public function ajax_get_status() {
        $stats = Logger::get_stats();

        if ( ! $stats ) {
            wp_send_json_error();
        }

        $result = $this->render_stats_html( $stats );

        wp_send_json_success( [
            'html'   => $result['html'],
            'status' => $stats['status'],
        ] );
    }
}
