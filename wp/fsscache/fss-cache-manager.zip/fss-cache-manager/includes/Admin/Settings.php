<?php
namespace FSS\Includes\Admin;

if ( ! defined( 'ABSPATH' ) ) exit;

class Settings {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_settings_page' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    public function add_settings_page() {
        add_options_page(
            'FSS Cache Settings',
            'FSS Cache',
            'manage_options',
            'fss-cache-settings',
            [ $this, 'render_page' ]
        );
    }

    public function register_settings() {
        register_setting( 'fss_cache_group', 'fss_exclude_urls' );
        register_setting( 'fss_cache_group', 'fss_always_purge_urls', [
            'sanitize_callback' => 'sanitize_textarea_field',
            'default'           => '',
        ] );
        register_setting( 'fss_cache_group', 'fss_preload_enabled', [
            'sanitize_callback' => 'absint',
            'default'           => 1,
        ] );
        register_setting( 'fss_cache_group', 'fss_preload_batch_size', [
            'sanitize_callback' => [ $this, 'sanitize_batch_size' ],
            'default'           => 100,
        ] );
        register_setting( 'fss_cache_group', 'fss_preload_concurrency', [
            'sanitize_callback' => [ $this, 'sanitize_concurrency' ],
            'default'           => 1,
        ] );
        register_setting( 'fss_cache_group', 'fss_preload_batch_delay', [
            'sanitize_callback' => [ $this, 'sanitize_batch_delay' ],
            'default'           => 10,
        ] );
        register_setting( 'fss_cache_group', 'fss_preload_schedule', [
            'sanitize_callback' => [ $this, 'sanitize_schedule' ],
            'default'           => 'daily',
        ] );
        register_setting( 'fss_cache_group', 'fss_preload_date_range', [
            'sanitize_callback' => 'absint',
            'default'           => 60,
        ] );
        register_setting( 'fss_cache_group', 'fss_preload_max_posts', [
            'sanitize_callback' => 'absint',
            'default'           => 0,
        ] );
        register_setting( 'fss_cache_group', 'fss_cache_max_age', [
            'sanitize_callback' => [ $this, 'sanitize_max_age' ],
            'default'           => 43200,
        ] );
        register_setting( 'fss_cache_group', 'fss_cache_s_maxage', [
            'sanitize_callback' => [ $this, 'sanitize_max_age' ],
            'default'           => 86400,
        ] );
    }

    public function sanitize_batch_size( $val ) {
        return max( 10, min( 500, intval( $val ) ) );
    }

    public function sanitize_concurrency( $val ) {
        return max( 1, min( 10, intval( $val ) ) );
    }

    public function sanitize_batch_delay( $val ) {
        return max( 5, min( 120, intval( $val ) ) );
    }

    public function sanitize_schedule( $val ) {
        $allowed = [ 'hourly', 'twicedaily', 'daily', 'weekly', 'lifetime' ];
        return in_array( $val, $allowed, true ) ? $val : 'daily';
    }

    public function sanitize_max_age( $val ) {
        return max( 0, min( 604800, intval( $val ) ) );
    }

    public function render_page() {
        $batch_size   = intval( get_option( 'fss_preload_batch_size', 100 ) );
        $concurrency  = intval( get_option( 'fss_preload_concurrency', 1 ) );
        $batch_delay  = intval( get_option( 'fss_preload_batch_delay', 10 ) );
        $schedule     = get_option( 'fss_preload_schedule', 'daily' );
        $enabled      = intval( get_option( 'fss_preload_enabled', 1 ) );
        $date_range   = intval( get_option( 'fss_preload_date_range', 60 ) );
        $max_posts    = intval( get_option( 'fss_preload_max_posts', 0 ) );
        $max_age      = intval( get_option( 'fss_cache_max_age', 43200 ) );
        $s_maxage     = intval( get_option( 'fss_cache_s_maxage', 86400 ) );
        $exclude_urls = get_option( 'fss_exclude_urls', '' );

        $schedules = [
            'hourly'     => 'Every Hour',
            'twicedaily' => 'Twice Daily',
            'daily'      => 'Once Daily',
            'weekly'     => 'Once a Week',
            'lifetime'   => 'Once Only (lifetime)',
        ];

        $date_presets = [
            7   => 'Last 7 days',
            14  => 'Last 14 days',
            30  => 'Last 30 days',
            60  => 'Last 60 days',
            90  => 'Last 90 days',
            180 => 'Last 6 months',
            365 => 'Last 1 year',
            0   => 'All time (no limit)',
        ];

        $is_custom_date = ! array_key_exists( $date_range, $date_presets );
        ?>
        <div class="wrap">
            <h1>FSS Cache Manager</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'fss_cache_group' ); ?>

                <h2 class="title">Preloader</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Enable Preloader</th>
                        <td>
                            <label>
                                <input type="checkbox" name="fss_preload_enabled" value="1" <?php checked( $enabled, 1 ); ?> />
                                Automatically warm cache on schedule
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Schedule</th>
                        <td>
                            <select name="fss_preload_schedule">
                                <?php foreach ( $schedules as $key => $label ) : ?>
                                    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $schedule, $key ); ?>>
                                        <?php echo esc_html( $label ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">How often the preloader runs automatically.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Batch Size</th>
                        <td>
                            <input type="number" name="fss_preload_batch_size"
                                value="<?php echo esc_attr( $batch_size ); ?>"
                                min="10" max="500" step="10" class="small-text" />
                            <p class="description">
                                URLs processed per cron run. Range: 10–500.<br>
                                Lower = less CPU/memory per run. Higher = finishes faster but uses more resources.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Concurrency</th>
                        <td>
                            <input type="number" name="fss_preload_concurrency"
                                value="<?php echo esc_attr( $concurrency ); ?>"
                                min="1" max="10" step="1" class="small-text" />
                            <p class="description">
                                Simultaneous requests per iteration. Range: 1–10.<br>
                                Keep at 1–3 for shared hosting. Higher values speed up preloading on dedicated servers.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Delay Between Batches</th>
                        <td>
                            <input type="number" name="fss_preload_batch_delay"
                                value="<?php echo esc_attr( $batch_delay ); ?>"
                                min="5" max="120" step="5" class="small-text" /> seconds
                            <p class="description">Wait time before the next batch starts. Range: 5–120 seconds.</p>
                        </td>
                    </tr>
                </table>

                <h2 class="title">Preload Scope</h2>
                <p class="description" style="margin: -8px 0 12px 0;">
                    Limit which posts/pages get preloaded. Both filters can be active at the same time — whichever is more restrictive wins.
                    Leave both at <strong>0 / All time</strong> to preload everything.
                </p>
                <table class="form-table">
                    <tr>
                        <th scope="row">Date Range</th>
                        <td>
                            <select id="fss_date_range_preset" onchange="fssHandleDatePreset(this)">
                                <?php foreach ( $date_presets as $days => $label ) : ?>
                                    <option value="<?php echo esc_attr( $days ); ?>"
                                        <?php selected( ! $is_custom_date && $date_range === $days ); ?>>
                                        <?php echo esc_html( $label ); ?>
                                    </option>
                                <?php endforeach; ?>
                                <option value="custom" <?php echo $is_custom_date ? 'selected' : ''; ?>>Custom…</option>
                            </select>

                            <span id="fss_date_custom_wrap" style="<?php echo $is_custom_date ? '' : 'display:none;'; ?> margin-left:8px;">
                                <input type="number" id="fss_date_custom_input"
                                    value="<?php echo esc_attr( $is_custom_date ? $date_range : '' ); ?>"
                                    min="1" step="1" class="small-text"
                                    placeholder="days"
                                    oninput="document.getElementById('fss_preload_date_range').value = this.value" />
                                <span class="description"> days</span>
                            </span>

                            <input type="hidden" name="fss_preload_date_range" id="fss_preload_date_range"
                                value="<?php echo esc_attr( $date_range ); ?>" />

                            <p class="description">
                                Only preload posts/pages published or modified within this period.<br>
                                <strong>0 = no date filter</strong> (preload all). Default: 60 days.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Max Posts</th>
                        <td>
                            <input type="number" name="fss_preload_max_posts"
                                value="<?php echo esc_attr( $max_posts ); ?>"
                                min="0" step="50" class="small-text" />
                            <p class="description">
                                Maximum number of URLs to preload per run. <strong>0 = no limit.</strong><br>
                                Useful for very large sites — e.g. set to <code>500</code> to only warm the 500 most recent posts.
                            </p>
                        </td>
                    </tr>
                </table>

                <h2 class="title">HTTP Cache Headers</h2>
                <p class="description" style="margin: -8px 0 12px 0;">
                    Controls <code>Cache-Control</code>, <code>ETag</code>, and <code>Last-Modified</code> headers sent to browsers and CDNs.
                    Only sent on cacheable frontend pages (not for logged-in users or excluded URLs).
                </p>
                <table class="form-table">
                    <tr>
                        <th scope="row">Browser Cache (max-age)</th>
                        <td>
                            <input type="number" name="fss_cache_max_age"
                                value="<?php echo esc_attr( $max_age ); ?>"
                                min="0" max="604800" step="3600" class="small-text" /> seconds
                            <p class="description">
                                How long browsers cache the page. Default: <code>43200</code> (12 hours).<br>
                                Set to <code>0</code> to disable browser caching (CDN/server cache still works).
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">CDN/Proxy Cache (s-maxage)</th>
                        <td>
                            <input type="number" name="fss_cache_s_maxage"
                                value="<?php echo esc_attr( $s_maxage ); ?>"
                                min="0" max="604800" step="3600" class="small-text" /> seconds
                            <p class="description">
                                How long CDN/reverse proxy caches the page. Default: <code>86400</code> (24 hours).<br>
                                This overrides <code>max-age</code> for shared caches (Cloudflare, Varnish, etc).
                            </p>
                        </td>
                    </tr>
                </table>

                <h2 class="title">Auto Purge URLs</h2>
                <p class="description" style="margin: -8px 0 12px 0;">
                    URLs that will <strong>always</strong> be purged whenever any post is created, updated, or deleted.<br>
                    Use this for custom homepage, landing pages with shortcodes, or any page that displays dynamic post lists.
                </p>
                <table class="form-table">
                    <tr>
                        <th scope="row">Always Purge URLs <span class="description">(one per line)</span></th>
                        <td>
                            <textarea name="fss_always_purge_urls" rows="8" cols="50" class="large-text code"><?php echo esc_textarea( get_option( 'fss_always_purge_urls', '' ) ); ?></textarea>
                            <p class="description">
                                URL paths or full URLs to always purge on post changes.<br>
                                Examples: <code>/</code> <code>/blog/</code> <code>/latest-news/</code> <code>/custom-home/</code><br>
                                Supports relative paths (e.g. <code>/my-page/</code>) or full URLs (e.g. <code>https://example.com/my-page/</code>).
                            </p>
                        </td>
                    </tr>
                </table>

                <h2 class="title">Cache Exclusions</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Exclude URLs <span class="description">(one per line)</span></th>
                        <td>
                            <textarea name="fss_exclude_urls" rows="12" cols="50" class="large-text code"><?php echo esc_textarea( $exclude_urls ); ?></textarea>
                            <p class="description">
                                URL paths to exclude from caching (e.g. <code>/checkout/</code> or <code>/my-account/</code>).<br>
                                Common paths: <code>/wp-admin/</code> <code>/wp-login.php</code> <code>/wp-cron.php</code>
                                <code>/xmlrpc.php</code> <code>/wp-json/</code> <code>/sitemap.xml</code>
                                <code>/cart/</code> <code>/checkout/</code> <code>/my-account/</code>
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>
        <script>
        function fssHandleDatePreset(sel) {
            var wrap  = document.getElementById('fss_date_custom_wrap');
            var input = document.getElementById('fss_preload_date_range');
            var custom = document.getElementById('fss_date_custom_input');

            if (sel.value === 'custom') {
                wrap.style.display = '';
                input.value = custom.value || '';
            } else {
                wrap.style.display = 'none';
                input.value = sel.value;
            }
        }
        </script>
        <?php
    }
}
