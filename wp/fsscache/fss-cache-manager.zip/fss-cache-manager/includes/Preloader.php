<?php
namespace FSS\Includes;

use FSS\Includes\Helpers;
use FSS\Includes\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class Preloader {

    const CRON_HOOK  = 'fss_preload_cron_event';
    const QUEUE_FILE = 'fss-preload-queue.json';
    const STOP_FILE  = 'fss-preload-stop';
    const MAX_DEPTH  = 3;

    public function __construct() {
        add_action( self::CRON_HOOK, [ $this, 'run_preload_batch' ] );
        add_action( 'update_option_fss_preload_schedule', [ $this, 'reschedule_on_change' ], 10, 2 );
        add_action( 'update_option_fss_preload_enabled', [ $this, 'toggle_on_change' ], 10, 2 );
    }

    private function get_batch_size() {
        return max( 10, min( 500, intval( get_option( 'fss_preload_batch_size', 100 ) ) ) );
    }

    private function get_concurrency() {
        return max( 1, min( 10, intval( get_option( 'fss_preload_concurrency', 1 ) ) ) );
    }

    private function get_batch_delay() {
        return max( 5, min( 120, intval( get_option( 'fss_preload_batch_delay', 10 ) ) ) );
    }

    private function get_schedule() {
        $allowed = [ 'hourly', 'twicedaily', 'daily', 'weekly', 'lifetime' ];
        $val     = get_option( 'fss_preload_schedule', 'daily' );
        return in_array( $val, $allowed, true ) ? $val : 'daily';
    }

    private function is_enabled() {
        return (bool) intval( get_option( 'fss_preload_enabled', 1 ) );
    }

    private function get_date_range_days() {
        return max( 0, intval( get_option( 'fss_preload_date_range', 60 ) ) );
    }

    private function get_max_posts() {
        return max( 0, intval( get_option( 'fss_preload_max_posts', 0 ) ) );
    }

    private function get_cutoff_date() {
        $days = $this->get_date_range_days();
        if ( $days === 0 ) return null;
        return date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
    }

    public function schedule_event() {
        if ( ! $this->is_enabled() ) return;
        if ( $this->get_schedule() === 'lifetime' ) return;
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time(), $this->get_schedule(), self::CRON_HOOK );
        }
    }

    public function clear_schedule() {
        wp_clear_scheduled_hook( self::CRON_HOOK );
    }

    public function reschedule_on_change( $old_value, $new_value ) {
        if ( $old_value === $new_value ) return;
        $this->clear_schedule();
        $this->schedule_event();
    }

    public function toggle_on_change( $old_value, $new_value ) {
        if ( intval( $new_value ) === 1 ) {
            $this->schedule_event();
        } else {
            $this->clear_schedule();
        }
    }

    private function queue_file_path() {
        return WP_CONTENT_DIR . '/' . self::QUEUE_FILE;
    }

    private function read_queue() {
        $path = $this->queue_file_path();
        if ( ! file_exists( $path ) ) return false;
        $data = json_decode( file_get_contents( $path ), true );
        return ( is_array( $data ) && isset( $data['urls'] ) ) ? $data : false;
    }

    private function write_queue( array $urls, int $index, string $run_id = '' ) {
        file_put_contents(
            $this->queue_file_path(),
            json_encode( [ 'urls' => $urls, 'index' => $index, 'run_id' => $run_id ] ),
            LOCK_EX
        );
    }

    private function delete_queue() {
        $path = $this->queue_file_path();
        if ( file_exists( $path ) ) unlink( $path );
    }

    private function stop_file_path() {
        return WP_CONTENT_DIR . '/' . self::STOP_FILE;
    }

    public function is_stop_requested() {
        return file_exists( $this->stop_file_path() );
    }

    public function request_stop() {
        file_put_contents( $this->stop_file_path(), time(), LOCK_EX );
    }

    private function clear_stop_flag() {
        $path = $this->stop_file_path();
        if ( file_exists( $path ) ) unlink( $path );
    }

    public function stop_and_cleanup() {
        wp_clear_scheduled_hook( self::CRON_HOOK );
        $this->delete_queue();
        $this->clear_stop_flag();

        $stats = Logger::get_stats();
        if ( $stats && isset( $stats['status'] ) && in_array( $stats['status'], [ 'running', 'scheduled' ], true ) ) {
            $progress = isset( $stats['progress'] ) ? intval( $stats['progress'] ) : 0;
            $total    = isset( $stats['total'] ) ? intval( $stats['total'] ) : 0;
            Logger::record_stopped( $progress, $total );
        }

        Logger::log( 'Preloader: Stopped by user.' );
    }

    public function prepare_new_run() {
        wp_clear_scheduled_hook( self::CRON_HOOK );
        $this->delete_queue();
        $this->clear_stop_flag();
    }

    public function run_preload_batch() {
        if ( ! $this->is_enabled() ) return;

        if ( $this->is_stop_requested() ) {
            $this->stop_and_cleanup();
            return;
        }

        @set_time_limit( 300 );

        $start_time   = microtime( true );
        $time_limit   = 120;
        $batch_size   = $this->get_batch_size();
        $concurrency  = $this->get_concurrency();
        $batch_delay  = $this->get_batch_delay();

        $queue         = $this->read_queue();
        $current_index = 0;
        $run_id        = '';

        if ( false === $queue ) {
            $run_id = wp_generate_uuid4();
            $urls   = $this->get_target_urls();
            if ( empty( $urls ) ) {
                Logger::error( 'Preloader: No URLs found.' );
                return;
            }
            $this->write_queue( $urls, 0, $run_id );
            Logger::start_log( count( $urls ) );
            Logger::log( "Preloader: Queue created for " . count( $urls ) . " URLs (run=$run_id)" );
        } else {
            $urls          = $queue['urls'];
            $current_index = intval( $queue['index'] );
            $run_id        = $queue['run_id'] ?? '';
        }

        $total_urls = count( $urls );

        while ( $current_index < $total_urls ) {
            if ( $this->is_stop_requested() ) {
                $this->stop_and_cleanup();
                return;
            }

            $fresh = $this->read_queue();
            if ( $fresh && ( $fresh['run_id'] ?? '' ) !== $run_id ) {
                Logger::log( 'Preloader: Run superseded, aborting.' );
                return;
            }

            $elapsed = microtime( true ) - $start_time;
            if ( $elapsed > $time_limit ) {
                $this->write_queue( $urls, $current_index, $run_id );
                Logger::update_progress( $current_index );
                Logger::log( "Preloader: Time limit reached ({$time_limit}s). Re-scheduling..." );
                wp_schedule_single_event( time() + 5, self::CRON_HOOK );
                spawn_cron();
                return;
            }

            $end_index = min( $current_index + $batch_size, $total_urls );
            $slice     = array_slice( $urls, $current_index, $end_index - $current_index );

            foreach ( array_chunk( $slice, $concurrency ) as $chunk ) {
                foreach ( $chunk as $url ) {
                    wp_remote_get( $url, [
                        'timeout'   => 0.01,
                        'blocking'  => false,
                        'sslverify' => false,
                        'headers'   => [
                            'Cache-Control'   => 'no-cache, must-revalidate',
                            'X-Accel-Expires' => '0',
                            'User-Agent'      => 'FSS-Cache-Manager-Preloader/1.10',
                        ],
                    ] );
                }
            }

            $current_index = $end_index;
            $this->write_queue( $urls, $current_index, $run_id );
            Logger::update_progress( $current_index );

            if ( $current_index < $total_urls && $batch_delay > 0 ) {
                for ( $w = 0; $w < $batch_delay; $w++ ) {
                    sleep( 1 );
                    if ( $this->is_stop_requested() ) {
                        $this->stop_and_cleanup();
                        return;
                    }
                }
            }
        }

        $duration = microtime( true ) - $start_time;
        Logger::record_stats( $total_urls, $duration );
        Logger::log( "Preloader: All $total_urls URLs completed in " . round( $duration, 1 ) . "s." );
        $this->delete_queue();
    }

    private function get_target_urls() {
        $sitemaps = [
            home_url( '/sitemap_index.xml' ),
            home_url( '/wp-sitemap.xml' ),
            home_url( '/sitemap.xml' ),
        ];

        foreach ( $sitemaps as $sm ) {
            $response = wp_remote_get( $sm, [ 'timeout' => 10, 'sslverify' => false ] );
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $urls = $this->parse_sitemap_recursive( $sm, 0 );
                if ( ! empty( $urls ) ) {
                    return $this->apply_max_posts_limit( $urls );
                }
            }
        }

        Logger::error( 'Preloader: Fallback Mode Active (No Sitemap Found)' );
        return $this->get_fallback_urls();
    }

    private function apply_max_posts_limit( array $urls ) {
        $max = $this->get_max_posts();
        if ( $max > 0 && count( $urls ) > $max ) {
            Logger::log( 'Preloader: Limiting URLs from ' . count( $urls ) . ' to ' . $max . ' (max posts setting)' );
            return array_slice( $urls, 0, $max );
        }
        return $urls;
    }

    private function get_fallback_urls() {
        $cutoff   = $this->get_cutoff_date();
        $max      = $this->get_max_posts();
        $urls     = [ home_url( '/' ) ];

        $post_limit = $max > 0 ? $max : 500;
        $page_limit = $max > 0 ? max( 1, intval( $max * 0.2 ) ) : 100;

        $post_args = [
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => $post_limit,
            'fields'         => 'ids',
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => true,
        ];

        $page_args = [
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => $page_limit,
            'fields'         => 'ids',
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => true,
        ];

        if ( $cutoff ) {
            $date_query = [ [ 'after' => $cutoff, 'inclusive' => true ] ];
            $post_args['date_query'] = $date_query;
            $page_args['date_query'] = $date_query;
        }

        $posts = get_posts( $post_args );
        foreach ( $posts as $p ) $urls[] = get_permalink( $p );

        $pages = get_posts( $page_args );
        foreach ( $pages as $p ) $urls[] = get_permalink( $p );

        $urls = array_values( array_unique( $urls ) );

        if ( $max > 0 && count( $urls ) > $max + 1 ) {
            $urls = array_slice( $urls, 0, $max + 1 );
        }

        return $urls;
    }

    private function parse_sitemap_recursive( $url, $depth ) {
        if ( $depth >= self::MAX_DEPTH ) return [];

        $response = wp_remote_get( $url, [ 'timeout' => 15, 'sslverify' => false ] );
        if ( is_wp_error( $response ) ) return [];

        $xml_content = wp_remote_retrieve_body( $response );
        if ( ! $xml_content ) return [];

        $cutoff = $this->get_cutoff_date();
        $urls   = [];

        try {
            libxml_use_internal_errors( true );
            $xml = new \SimpleXMLElement( $xml_content );

            if ( isset( $xml->sitemap ) ) {
                foreach ( $xml->sitemap as $sm ) {
                    if ( $cutoff && isset( $sm->lastmod ) ) {
                        $lastmod = strtotime( (string) $sm->lastmod );
                        if ( $lastmod && $lastmod < strtotime( $cutoff ) ) {
                            continue;
                        }
                    }
                    $child = $this->parse_sitemap_recursive( (string) $sm->loc, $depth + 1 );
                    $urls  = array_merge( $urls, $child );
                }
            } elseif ( isset( $xml->url ) ) {
                foreach ( $xml->url as $u ) {
                    if ( $cutoff && isset( $u->lastmod ) ) {
                        $lastmod = strtotime( (string) $u->lastmod );
                        if ( $lastmod && $lastmod < strtotime( $cutoff ) ) {
                            continue;
                        }
                    }
                    $urls[] = (string) $u->loc;
                }
            }

            libxml_clear_errors();
        } catch ( \Exception $e ) {
            return [];
        }

        return array_values( array_unique( $urls ) );
    }
}
