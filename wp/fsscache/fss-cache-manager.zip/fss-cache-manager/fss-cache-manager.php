<?php
/**
 * Plugin Name: FSS Cache Manager
 * Description: High-performance Nginx FastCGI Cache Manager. Includes Smart Purge, Sitemap Preloader.
 * Version: 1.10.3-beta
 * Author: FSS
 */

namespace FSS;

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'FSS_VERSION', '1.10.3-beta' );
define( 'FSS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'FSS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'FSS_PLUGIN_FILE', __FILE__ );

require_once FSS_PLUGIN_DIR . 'includes/Core.php';

function init() {
    new Includes\Core();
}
add_action( 'plugins_loaded', __NAMESPACE__ . '\init' );
